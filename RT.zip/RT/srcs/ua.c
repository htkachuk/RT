/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ua.c                                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: htkachuk <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/06/15 13:35:36 by htkachuk          #+#    #+#             */
/*   Updated: 2018/06/15 13:35:40 by htkachuk         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/rtv1.h"

static void	grey(t_env *ev, int x_min, int x_max, int y_min, int y_max)
{
	int		x;
	int		y;
	t_color	color;


	y = y_min - 1;
	while (++y < y_max)
	{
		x = x_min - 1;
		while (++x < x_max)
			mlx_pixel_put(ev->mlx, ev->win, x, y, 0xFFFFFF);
	}
}

static void square(t_env *ev, int x_min, int y_min, int x_max, int y_max)
{
	int	x;
	int	y;

	y = y_min;
	x = x_min - 1;
	while (++x < x_max)
		mlx_pixel_put(ev->mlx, ev->win, x, y, 0x000000);
	y = y_max;
	x = x_min - 1;
	while (++x < x_max)
		mlx_pixel_put(ev->mlx, ev->win, x, y, 0x000000);
	y = y_min - 1;
	while (++y < y_max)
		mlx_pixel_put(ev->mlx, ev->win, x, y, 0x000000);
	y = y_min - 1;
	x = x_min;
	while (++y < y_max)
		mlx_pixel_put(ev->mlx, ev->win, x, y, 0x000000);

}

int mouse_camera_hook(int keycode, int x, int y, t_env *ev)
{
	if (keycode == 1)
		if ((x > 310 && x < 490 && y > 835 && y < 965)
			|| (x > 465 && x < 475 && y > 815 && y < 835))
			printf("camera!\n");
		if (x > 10 && x < 150 && y > 805 && y < 835)
			re_draw_effect(ev, 0);
		if (x > 10 && x < 150 && y > 845 && y < 875)
			re_draw_effect(ev, 1);
		if (x > 10 && x < 150 && y > 885 && y < 920)
			re_draw_effect(ev, 2);
		if (x > 10 && x < 150 && y > 930 && y < 960)
			re_draw_effect(ev, 3);
	return (0);
}

static void	black(t_env *ev, int x_min, int x_max, int y_min, int y_max)
{
	int		x;
	int		y;
	t_color	color;


	y = y_min - 1;
	while (++y < y_max)
	{
		x = x_min - 1;
		while (++x < x_max)
			mlx_pixel_put(ev->mlx, ev->win, x, y, 0x000000);
	}
}

void	make_screenshot(t_env *ev)
{
	grey(ev, 0, 800, 800, 1000);
	square(ev, 310, 835, 490, 965);
	square(ev, 375, 875, 425, 925);
	square(ev, 390, 890, 410, 910);
	square(ev, 460, 845, 480, 855);
	square(ev, 465, 815, 475, 835);
	black(ev, 309, 491, 834, 966);
	white(ev, 310, 490, 835, 965);
	black(ev, 310, 490, 835, 870);
	grey(ev, 465, 480, 845, 855);
	black(ev, 375, 425, 875, 925);
	grey(ev, 390, 410, 890, 910);

}
