/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   color_filters.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: htkachuk <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/06/14 12:08:46 by htkachuk          #+#    #+#             */
/*   Updated: 2018/06/14 12:08:49 by htkachuk         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/rtv1.h"

void	make_color_normal(t_math *m)
{
	m->color.r = (double)(MIN(m->color.r * 255, 255));
	m->color.g = (double)(MIN(m->color.g * 255, 255));
	m->color.b = (double)(MIN(m->color.b * 255, 255));
}

void	make_black_white(t_math *m)
{
	double	temp;

	temp = (m->color.r + m->color.g + m->color.b) / 3;
	m->color.r = temp;
	m->color.g = temp;
	m->color.b = temp;
}

void	make_cartoon(t_math *m)
{
	int		i;
	double	*temp;

	i = -1;
	temp = &(m->color.r);
	while(++i < 3)
	{
		if (*temp >= 0 && *temp <= 50)
			*temp = 25;
		if (*temp >= 50 && *temp <= 100)
			*temp = (50 + 100) / 2;
		if (*temp >= 100 && *temp <= 150)
			*temp = (150 + 100) / 2;
		if (*temp >= 150 && *temp <= 200)
			*temp = (150 + 200) / 2;
		if (*temp >= 200 && *temp <= 255)
			*temp = (255 + 200) / 2;
		temp = ((i == 1 && i != 0) ? &(m->color.g) : &(m->color.b));
	}
}

void	make_sepia(t_math *m)
{
	double	tr;
	double	tg;
	double	tb;

	tr = 0.393 * m->color.r + 0.769 * m->color.g + 0.189 * m->color.b;
	tg = 0.349 * m->color.r + 0.686 * m->color.g + 0.168 * m->color.b;
	tb = 0.272 * m->color.r + 0.534 * m->color.g + 0.131 * m->color.b;
	tr = (tr > 255) ? 255 : tr;
	tg = (tg > 255) ? 255 : tg;
	tb = (tb > 255) ? 255 : tb;
	m->color.r = tr;
	m->color.g = tg;
	m->color.b = tb;
}
// void	make_blur()
// {
// 	int	x;
// 	int	y;

// 	y = 0;
// 	while (++y < (WHIDTH - 1))
// 	{
// 		x = -1;
		
// 	}
// }
