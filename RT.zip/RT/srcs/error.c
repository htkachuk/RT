/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   error.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: htkachuk <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/06/15 11:34:54 by htkachuk          #+#    #+#             */
/*   Updated: 2018/06/15 11:34:56 by htkachuk         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/rtv1.h"

void	white(t_env *ev, int x_min, int x_max, int y_min, int y_max)
{
	int		x;
	int		y;

	y = y_min - 1;
	while (++y < y_max)
	{
		x = x_min - 1;
		while (++x < x_max)
			mlx_pixel_put(ev->mlx, ev->win, x, y, 0xC8C8C8);
	}
}

static void	like_button(t_env *ev)
{
	int	x;
	int	y;

	y = 90;
	while (++y < 130)
	{
		x = 109;
		while (++x < 170)
			mlx_pixel_put(ev->mlx, ev->win, x, y, 0x808080);
	}
}

static int 	mouse_error_hook(int keycode, int x, int y)
{
	if (keycode == 1)
		if (x > 109 && x < 170 && y > 90 && y < 130)
			exit (0);
	return (0);
}

int		error_end(char *str, t_env *env)
{
	env->img = (t_img *)malloc(sizeof(t_img));
	env->mlx = mlx_init();
	env->win = mlx_new_window(env->mlx, 300, 150, "ERROR!!!!!");
	white(env, 0, 300, 0, 200);
	mlx_string_put(env->mlx, env->win, 30, 40, 0xFF0000, str);
	like_button(env);
	mlx_string_put(env->mlx, env->win, 130, 100, 0x000000, "OK");
	mlx_hook(env->win, 17, 1L << 17, end, env);
	mlx_hook(env->win, 4, 1L << 2, mouse_error_hook, env);
	mlx_loop(env->mlx);
	return (0);
}
